function opt=__new_download_link__(options)
	opt=options;
	%opt.download_link = "http://downloads.sourceforge.net/octave/%name-%version.tar.gz?download";
	opt.download_link = "http://download.savannah.gnu.org/releases/bsltl/";

end
