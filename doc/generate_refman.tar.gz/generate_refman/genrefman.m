%
addpath('mymfiles');

options = get_html_options ("octave-forge");

options=__new_header__(options);

generate_package_html ("bsltl", "bsltl_refman",options)

copyfile("datafiles/octave-forge.css","bsltl_refman/octave-forge.css");
copyfile("datafiles/fixed.js","bsltl_refman/fixed.js");
copyfile("datafiles/javascript.js","bsltl_refman/javascript.js");

copyfile("datafiles/doc.png","bsltl_refman/doc.png");
copyfile("datafiles/download.png","bsltl_refman/download.png");
copyfile("datafiles/news.png","bsltl_refman/news.png");
copyfile("datafiles/oct.png","bsltl_refman/oct.png");
copyfile("datafiles/favicon.ico","bsltl_refman/favicon.ico");

rmpath('mymfiles');

